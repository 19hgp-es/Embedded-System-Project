#include <stdio.h>
#include <memory.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <dirent.h>
#include <inttypes.h>
#include <sys/time.h>
#include <stdbool.h>


#define SDRAM_BASE_ADDR 0
#define ALT_VIP_SOFTWARE_RESET_N_BASE 0x00000200   //


#define ALT_AXI_FPGASLVS_OFST (0xC0000000)  // axi_master
#define HW_FPGA_AXI_SPAN (0x40000000)  // Bridge span
#define HW_FPGA_AXI_MASK ( HW_FPGA_AXI_SPAN - 1 )


#define DEMO_VGA_FRAME0_ADDR		0x00000000
#define FR0_FRAME0_OFFSET			0x00000000



static volatile unsigned long *h2p_memory_addr=NULL;


int pixel_processing( int Red, int Green, int Blue, int None )
{
	int pixel;
	int Red_temp, Green_temp, Blue_temp;


	Red_temp = Red;
	Green_temp = Green;
	Blue_temp = Blue;


	pixel = (Green_temp<<24) | (Blue_temp<<16) | (None<<8) | Red_temp;

	return pixel;
};


int main() {


	void *virtual_base;
	void *axi_virtual_base;
	int fd;

	int i, n, adr;
	int num;	

	unsigned char tt[60], buf[4], file[20];
	static volatile unsigned long *output_data = NULL;
	long Red, Green, Blue, None, pixel;

	FILE *fpi;

	printf("\n");
	printf("#########################################################\n");
	printf("#                                                       #\n");
	printf("# Embedded System                                       #\n");
	printf("# Image Processing Project                              #\n");
	printf("#                                                       #\n");
	printf("# Prof. Yongjun Park                                    #\n");
	printf("#                                                       #\n");
	printf("#########################################################\n\n");

	printf("Image name (ex: lena.bmp) : ");
	scanf("%s", file);



	if((fpi = fopen(file, "rb")) == NULL) {

		printf("File not found\n", file);
		exit(0);
	}
 
	if( ( fd = open( "/dev/mem", ( O_RDWR | O_SYNC ) ) ) == -1 ) {
		printf( "ERROR: could not open \"/dev/mem\"...\n" );
		return( 1 );
	}

	axi_virtual_base  = mmap( NULL, HW_FPGA_AXI_SPAN, ( PROT_READ | PROT_WRITE ), MAP_SHARED, fd,ALT_AXI_FPGASLVS_OFST  );	
	if( axi_virtual_base == MAP_FAILED ) {
		printf( "ERROR: axi mmap() failed...\n" );
		close( fd );
		return( 1 );
	}


	h2p_memory_addr=axi_virtual_base + ( ( unsigned long  )( DEMO_VGA_FRAME0_ADDR) & ( unsigned long)( HW_FPGA_AXI_MASK ) );
	

	fread(tt, 54, 1, fpi);
 
	output_data = h2p_memory_addr;


	num = 0;
	while( fread(buf, 4, 1, fpi) != 0 ) {

		num += 1;

		Red = (long)buf[2];
		Green = (long)buf[1];
		Blue = (long)buf[0];
		None = (long)buf[3];

		pixel = pixel_processing(Red, Green, Blue, None);
		
		*output_data = pixel;
		output_data += 1;

		}
	
	printf("Total number of Pixels : %d \n", num);
	printf("Image Load Complete!\n");
	fclose(fpi);

	return 0;
}
